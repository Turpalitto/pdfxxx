import { FileText, Globe, Sparkles } from 'lucide-react';
import { Button } from './ui/button';

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-white/10 bg-slate-950/80 backdrop-blur-xl">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <div className="relative flex size-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-blue-500/50">
            <FileText className="size-6 text-white" />
            <div className="absolute -top-1 -right-1 flex size-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full size-3 bg-emerald-500"></span>
            </div>
          </div>
          <span className="text-xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
            PDF<span className="text-blue-400">X</span>
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-8">
          <a href="#tools" className="text-sm text-slate-300 hover:text-white transition-colors">
            Инструменты
          </a>
          <a href="#features" className="text-sm text-slate-300 hover:text-white transition-colors">
            Возможности
          </a>
          <a href="#ai" className="text-sm text-slate-300 hover:text-white transition-colors">
            AI
          </a>
        </nav>

        <div className="flex items-center gap-4">
          <button className="hidden md:flex items-center gap-2 text-sm text-slate-300 hover:text-white transition-colors">
            <Globe className="size-4" />
            Русский
          </button>
          <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 shadow-lg shadow-blue-500/30 text-white">
            <Sparkles className="size-4 mr-2" />
            Купить Pro
          </Button>
        </div>
      </div>
    </header>
  );
}