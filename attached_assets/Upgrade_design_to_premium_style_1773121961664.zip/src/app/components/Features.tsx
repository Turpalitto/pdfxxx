import { FileX, Zap, Monitor, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

export function Features() {
  const features = [
    {
      icon: FileX,
      title: 'Файлы не загружаются',
      description: 'Обработка происходит локально',
      gradient: 'from-yellow-500 to-orange-500',
    },
    {
      icon: Zap,
      title: 'Мгновенная обработка',
      description: 'Быстрее, чем на серверах',
      gradient: 'from-orange-500 to-red-500',
    },
    {
      icon: Monitor,
      title: 'Работает офлайн',
      description: 'Нет зависимости от сервера',
      gradient: 'from-cyan-500 to-blue-500',
    },
    {
      icon: ShieldCheck,
      title: 'Без регистрации',
      description: 'Анонимно и безопасно',
      gradient: 'from-pink-500 to-purple-500',
    },
  ];

  return (
    <section id="features" className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {features.map((feature, index) => {
          const Icon = feature.icon;
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-slate-900/30 p-6 backdrop-blur-sm hover:border-white/20 transition-all duration-300"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-purple-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative">
                <div className={`inline-flex items-center justify-center size-12 rounded-xl bg-gradient-to-br ${feature.gradient} shadow-lg mb-4`}>
                  <Icon className="size-6 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2">{feature.title}</h3>
                <p className="text-sm text-slate-400">{feature.description}</p>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}