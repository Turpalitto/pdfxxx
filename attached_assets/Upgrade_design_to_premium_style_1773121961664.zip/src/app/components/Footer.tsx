import { FileText, Github, Twitter, Linkedin } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-slate-950/80 backdrop-blur-xl">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="flex size-10 items-center justify-center rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 shadow-lg shadow-blue-500/50">
                <FileText className="size-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
                PDF<span className="text-blue-400">X</span>
              </span>
            </div>
            <p className="text-sm text-slate-400">
              Все PDF инструменты в одном месте. Бесплатно, безопасно, без водяных знаков.
            </p>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Инструменты</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">PDF в Word</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Объединить PDF</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Сжать PDF</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Все инструменты</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Компания</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">О нас</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Блог</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Карьера</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Контакты</a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-white font-semibold mb-4">Правовая информация</h3>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Условия использования</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Политика конфиденциальности</a></li>
              <li><a href="#" className="text-slate-400 hover:text-white transition-colors">Cookie</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-slate-400">
              © 2026 PDFX. Все права защищены.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Twitter className="size-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Github className="size-5" />
              </a>
              <a href="#" className="text-slate-400 hover:text-white transition-colors">
                <Linkedin className="size-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
