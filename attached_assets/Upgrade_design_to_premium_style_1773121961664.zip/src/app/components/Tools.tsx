import { 
  FileText, 
  Image, 
  Upload, 
  FileSpreadsheet, 
  FileImage,
  Link,
  Scissors,
  RotateCw,
  Trash2,
  Lock,
  Unlock,
  CloudUpload,
  Droplet,
  Globe,
  FileEdit,
  Pencil,
  Camera,
  Hash,
  Table,
  LucideIcon
} from 'lucide-react';
import { motion } from 'motion/react';

interface Tool {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  gradient: string;
  category: string;
}

const tools: Tool[] = [
  { id: '1', title: 'PDF в Word', description: 'Конвертируйте PDF файлы в редактируемые документы...', icon: FileText, gradient: 'from-blue-500 to-blue-600', category: 'convert' },
  { id: '2', title: 'PDF в JPG', description: 'Конвертируйте страницы PDF в изображения JPG высокого...', icon: FileImage, gradient: 'from-yellow-500 to-orange-500', category: 'convert' },
  { id: '3', title: 'PDF в PNG', description: 'Конвертируйте страницы PDF в изображения PNG с...', icon: Image, gradient: 'from-green-500 to-emerald-500', category: 'convert' },
  { id: '4', title: 'PDF в Текст', description: 'Быстро и чисто извлекайте весь текстовый контент из PDF...', icon: FileEdit, gradient: 'from-purple-500 to-violet-500', category: 'convert' },
  { id: '5', title: 'PDF в HTML', description: 'Конвертируйте PDF документы в формат HTML для веб...', icon: Globe, gradient: 'from-cyan-500 to-blue-500', category: 'convert' },
  { id: '6', title: 'PDF в Excel', description: 'Извлекайте таблицы как PDF файлы в редактируемые...', icon: FileSpreadsheet, gradient: 'from-red-500 to-pink-500', category: 'convert' },
  { id: '7', title: 'Word в PDF', description: 'Мгновенно конвертируйте документы Word (.docx) в...', icon: FileText, gradient: 'from-indigo-500 to-purple-500', category: 'convertFrom' },
  { id: '8', title: 'Фото в PDF', description: 'Объедините несколько изображений JPG или PNG в...', icon: Camera, gradient: 'from-orange-500 to-red-500', category: 'convertFrom' },
  { id: '9', title: 'Excel в PDF', description: 'Конвертируйте таблицы Excel в PDF документы...', icon: Table, gradient: 'from-pink-500 to-rose-500', category: 'convertFrom' },
  { id: '10', title: 'Текст в PDF', description: 'Конвертируйте текстовые файлы или вставленный конт...', icon: Pencil, gradient: 'from-yellow-500 to-amber-500', category: 'convertFrom' },
  { id: '11', title: 'Объединить PDF', description: 'Объедините несколько PDF файлов в один. Перетащите д...', icon: Upload, gradient: 'from-teal-500 to-cyan-500', category: 'organize' },
  { id: '12', title: 'Разделить PDF', description: 'Разделите PDF по диапазонам страниц, каждые N страниц ил...', icon: Scissors, gradient: 'from-red-500 to-orange-500', category: 'organize' },
  { id: '13', title: 'Повернуть PDF', description: 'Поворачивайте страницы PDF на 90°, 180° или 270° по...', icon: RotateCw, gradient: 'from-blue-500 to-indigo-500', category: 'organize' },
  { id: '14', title: 'Удалить страницы', description: 'Удаляйте конкретные страницы из PDF с помощью визуально...', icon: Trash2, gradient: 'from-cyan-500 to-teal-500', category: 'organize' },
  { id: '15', title: 'Перепорядочить', description: 'Переташите страницы PDF в нужный порядок...', icon: Hash, gradient: 'from-purple-500 to-pink-500', category: 'organize' },
  { id: '16', title: 'Извлечь страницы', description: 'Извлекайте конкретные страницы из PDF в новый...', icon: CloudUpload, gradient: 'from-emerald-500 to-green-500', category: 'organize' },
  { id: '17', title: 'Защитить PDF', description: 'Добавьте шифрование AES-256 с паролем для защиты ваших...', icon: Lock, gradient: 'from-yellow-600 to-orange-600', category: 'security' },
  { id: '18', title: 'Снять защиту', description: 'Удалите парольную защиту с PDF файлов, которыми вы...', icon: Unlock, gradient: 'from-slate-600 to-slate-700', category: 'security' },
  { id: '19', title: 'Подписать PDF', description: 'Нарисуйте подпись или загрузите изображение и...', icon: Pencil, gradient: 'from-orange-500 to-amber-500', category: 'security' },
  { id: '20', title: 'Водяной знак', description: 'Добавьте пользовательские текстовые или графические...', icon: Droplet, gradient: 'from-blue-500 to-cyan-500', category: 'security' },
];

interface ToolsProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

export function Tools({ selectedCategory, onCategoryChange }: ToolsProps) {
  const categories = [
    { id: 'all', label: 'Все инструменты' },
    { id: 'convertFrom', label: 'Конвертация из PDF' },
    { id: 'convert', label: 'Конвертация в PDF' },
    { id: 'organize', label: 'Организация' },
    { id: 'security', label: 'Безопасность' },
    { id: 'optimize', label: 'Оптимизация' },
    { id: 'ocr', label: 'OCR и сканирование' },
    { id: 'remove', label: 'Утилиты' },
  ];

  const filteredTools = selectedCategory === 'all' 
    ? tools 
    : tools.filter(tool => tool.category === selectedCategory);

  return (
    <section id="tools" className="container mx-auto px-4 py-16">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="text-center mb-12"
      >
        <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
          Все PDF инструменты в одном месте
        </h2>
        <p className="text-slate-400 text-lg">
          28 инструментов в 7 категориях. Бесплатно, без регистрации.
        </p>
      </motion.div>

      <div className="flex flex-wrap justify-center gap-3 mb-12">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => onCategoryChange(category.id)}
            className={`px-6 py-2.5 rounded-full text-sm font-medium transition-all duration-300 ${
              selectedCategory === category.id
                ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg shadow-blue-500/30'
                : 'bg-slate-800/50 text-slate-300 border border-slate-700 hover:border-slate-600 hover:bg-slate-800'
            }`}
          >
            {category.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredTools.map((tool, index) => {
          const Icon = tool.icon;
          return (
            <motion.div
              key={tool.id}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900/50 to-slate-800/30 p-6 backdrop-blur-sm hover:border-white/20 transition-all duration-300 cursor-pointer hover:scale-105"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className="relative">
                <div className={`inline-flex items-center justify-center size-14 rounded-xl bg-gradient-to-br ${tool.gradient} shadow-lg shadow-${tool.gradient.split('-')[1]}-500/50 mb-4`}>
                  <Icon className="size-7 text-white" />
                </div>
                <h3 className="text-white font-semibold mb-2 text-lg">{tool.title}</h3>
                <p className="text-sm text-slate-400 leading-relaxed">{tool.description}</p>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
}