import { Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

export function AIAssistant() {
  return (
    <section id="ai" className="container mx-auto px-4 py-20">
      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="relative overflow-hidden rounded-3xl border border-purple-500/30 bg-gradient-to-br from-purple-950/50 via-blue-950/50 to-slate-950/50 backdrop-blur-sm"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-blue-500/10" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_120%,rgba(120,119,198,0.3),rgba(255,255,255,0))]" />
        
        <div className="relative px-8 py-16 md:px-16 text-center">
          <motion.div 
            initial={{ scale: 0 }}
            whileInView={{ scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="inline-flex items-center justify-center size-16 rounded-2xl bg-gradient-to-br from-purple-500 to-blue-500 shadow-2xl shadow-purple-500/50 mb-6"
          >
            <Sparkles className="size-8 text-white" />
          </motion.div>
          
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="text-4xl md:text-5xl font-bold mb-4"
          >
            <span className="bg-gradient-to-r from-white to-purple-200 bg-clip-text text-transparent">
              Встроенный 
            </span>
            {' '}
            <span className="bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              AI-ассистент
            </span>
            <br />
            <span className="bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">
              для ваших документов
            </span>
          </motion.h2>
          
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="text-lg text-slate-300 max-w-2xl mx-auto mb-8 leading-relaxed"
          >
            Используйте искусственный интеллект для автоматической обработки, извлечения данных и анализа ваших PDF документов.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="flex flex-wrap justify-center gap-4 text-sm text-slate-400"
          >
            <div className="flex items-center gap-2 bg-slate-900/50 rounded-full px-4 py-2 border border-slate-700">
              <div className="size-2 rounded-full bg-green-500" />
              договор-аренды.pdf (24 стр.)
            </div>
            <div className="flex items-center gap-2 bg-slate-900/50 rounded-full px-4 py-2 border border-slate-700">
              <div className="size-2 rounded-full bg-purple-500" />
              + какой срок аренды в играх за просрочку?»
            </div>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}