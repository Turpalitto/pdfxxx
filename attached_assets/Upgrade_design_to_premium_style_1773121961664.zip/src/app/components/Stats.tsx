import { motion } from 'motion/react';

export function Stats() {
  const stats = [
    { value: '2M+', label: 'ФАЙЛОВ ОБРАБОТАНО', color: 'from-purple-400 to-pink-400' },
    { value: '180+', label: 'СТРАН', color: 'from-blue-400 to-cyan-400' },
    { value: '28', label: 'PDF ИНСТРУМЕНТОВ', color: 'from-emerald-400 to-green-400' },
    { value: '100%', label: 'БЕСПЛАТНО НАЧАТЬ', color: 'from-yellow-400 to-orange-400' },
  ];

  return (
    <section className="container mx-auto px-4 py-16">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            className="group relative overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br from-slate-900/50 to-slate-800/30 p-6 backdrop-blur-sm hover:border-white/20 transition-all duration-300"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            <div className="relative">
              <div className={`text-4xl md:text-5xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-2`}>
                {stat.value}
              </div>
              <div className="text-xs text-slate-400 tracking-wider">
                {stat.label}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}