import { useState } from 'react';
import { Hero } from './components/Hero';
import { Stats } from './components/Stats';
import { Features } from './components/Features';
import { Tools } from './components/Tools';
import { Header } from './components/Header';
import { AIAssistant } from './components/AIAssistant';
import { Footer } from './components/Footer';
import { AnimatedBackground } from './components/AnimatedBackground';

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState('all');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 relative">
      <AnimatedBackground />
      <div className="relative z-10">
        <Header />
        <Hero />
        <Stats />
        <Features />
        <Tools selectedCategory={selectedCategory} onCategoryChange={setSelectedCategory} />
        <AIAssistant />
        <Footer />
      </div>
    </div>
  );
}