
  # Upgrade design to premium style

  This is a code bundle for Upgrade design to premium style. The original project is available at https://www.figma.com/design/i05OpWNIRssUBR3DzOJJNL/Upgrade-design-to-premium-style.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  